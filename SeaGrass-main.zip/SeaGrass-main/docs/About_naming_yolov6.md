# About the naming of YOLOv6

### WHY named YOLOv6 ?
The full name is actually MT-YOLOv6, which is called YOLOv6 for brevity. Our work is majorly inspired by the original idea of the one-stage YOLO detection algorithm and the implementation has leveraged various techniques and tricks of former relevant work . Therefore, we named the project YOLOv6 to pay tribute to the work of YOLO series. Furthermore, we have indeed adopted some novel method and made solid engineering improvements to dedicate the algorithm to industrial applications.
As for the project, we'll continue to improve and maintain it, contributing more values for industrial applications.

P.S. We are contacting the authors of YOLO series about the naming of YOLOv6.

Thanks for your attention！
