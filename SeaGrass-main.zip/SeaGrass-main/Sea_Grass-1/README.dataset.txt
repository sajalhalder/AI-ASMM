# Sea_Grass > 2022-10-28 9:42pm
https://universe.roboflow.com/cquniversityseagrass/sea_grass

Provided by a Roboflow user
License: CC BY 4.0

